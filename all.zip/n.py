#กลุ่มไลฟสด=========================================================================================#

#------------line_notify.py------------
#!/usr/local/bin/python
# -*- coding: utf-8 -*-
import requests

url = 'https://notify-api.line.me/api/notify'
#มุดเทส
token = 'EwoDbDsDzziPKC5WhKmGDneLJurjXroUu6kkyjNwAq9'
headers = {'content-type':'application/x-www-form-urlencoded','Authorization':'Bearer '+token}

msg = "ช่วงนี้ทยอยย้ายกลุ่มสมาชิกท่านไหนที่ยังไม่ได้เข้ากลุ่มใหม่ทักแอดมินสุดสวยไปได้เลยนะครับ "
#msg = "💻สนใจโปรแกรม แอพสแกน 🔔\n\n⛔โปรแกรม 918 Scan Win (New Version 2.0.1)\n\n👉รองรับภาษาไทย-ใช้งานถาวร\n\n🙅เสถียรระบบไม่ error \n\n😎 รองรับทุกเอเย่น 918 Kiss ในประเทศไทย\n\n       ราคา 500 บาท\n  ใช้งานถาวร ไม่หมดอายุ\n          มีกลุ่มไลน์\n\nสนใจติดต่อ....\n\nvipscanner_win\n\nhttp://line.me/ti/p/xWX1CmxQ0\nhttp://line.me/ti/p/xWX1CmxrQ0\n\nโทร. 098-9512879\n\nŚẾL₣ВΌŦ BY:\n╔════════════════════┓\n╠ 🔥Hack Scan 🔔Win🔔\n╚════════════════════┛ "
#msg = "หรือต้องการทดสอบก่อนนะครับตัวนี้แจกฟรีเป็นตัวทดสอบสามารถดาวน์โหลดได้เลยครับ \n\nhttps://drive.google.com/file/d/12O1PKrXWujpb_nfQUWN53dJTQz-HhU1M/view?usp=drivesdk"
r = requests.post(url, headers=headers, data = {'message':msg})

print ("เรียบร้อย")
